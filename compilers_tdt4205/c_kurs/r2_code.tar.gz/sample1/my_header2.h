#include "mylibrary.h"

float vector_length(float v1x, float v1y)
{
    float len = sqrt(dot_product(v1x,v1y,v1x,v1y));
    
}
