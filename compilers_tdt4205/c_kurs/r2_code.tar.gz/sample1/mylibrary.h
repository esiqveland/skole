#ifndef __MYLIBRARY_H__
#define __MYLIBRARY_H__

float dot_product(float v1x, float v1y, float v2x, float v2y)
{
    return v1x*v2x+v1y*v2y;
}

#endif
